<section class="pb-70 pt-100" id="teams">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="section-title text-center">
					<h2>Our Team</h2>
				</div>
			</div>
		</div>
		<div class="destination-slider-active owl-carousel">
            @foreach ($teams as $team)
            <div class="single-destination">
				<figure>
					<img src="{{ asset('uploads/teams') }}/{{ $team->image }}" alt="">
				</figure>
				<div class="des-city text-center">
					<h3>{{ $team->name }} </h3>
					<h4>{{ $team->designation }} </h4>
				</div>
			</div> <!-- single popular destination  end-->

            @endforeach

		</div>
	</div>
</section> <!-- end popular destination-->
