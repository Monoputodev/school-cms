<section class="news-info">
    <div class="container">
        <div class="row">

            <div class="col-sm-12 col-md-12 col-lg-12 content-page">
                <!-- Begin: content -->

                <div id="passage">
                    <div class="section-title-version-2-white text-center">
                        <h2 style="color: #000">News & Info</h2>
                    </div>
                    <div class="paragraph page-para">

                        @foreach ($notices->take(5) as $notice)
                            <div class="several-news">
                                <h3>{{ $notice->title }}</h3>
                                @if($notice->subtitle)
                                <p class="p-2">{{ $notice->subtitle }}</p>
                                @endif

                                <div class="entry-utility">
                                    {{ \Carbon\Carbon::parse($notice->created_at)->format('d M, Y') }}
                                </div>
                                <a href="{{ asset('uploads/notices/' . $notice->pdf_file) }}"
                                    target="_blank" class="\&quot;more2\&quot;">বিস্তারিত তথ্য ডাউনলোড করার জন্যএইখানে ক্লিক করুন</a>
                            </div> <!-- End: several news -->
                        @endforeach




                        <!-- show pagination here -->

                    </div>
                    {{-- <center>
                        <div class="pagination"><span>Page 1 of 275</span><span class="current">1</span><a
                                href="https://hajj.gov.bd/news-and-info/page/2/" class="inactive">2</a><a
                                href="https://hajj.gov.bd/news-and-info/page/3/" class="inactive">3</a><a
                                href="https://hajj.gov.bd/news-and-info/page/4/" class="inactive">4</a><a
                                href="https://hajj.gov.bd/news-and-info/page/5/" class="inactive">5</a><a
                                href="https://hajj.gov.bd/news-and-info/page/2/">Next ›</a><a
                                href="https://hajj.gov.bd/news-and-info/page/275/">Last »</a></div>
                    </center> --}}

                </div>

            </div><!-- End: content -->

                        <div class="col-md-12 text-center">
                            <div class="single-travel">
                                <div class="media">

                                    <div class="media-body travel-content">
                                        <a href="{{ route('notice.all') }}" target="_blank">View All</a>
                                    </div>
                                </div>
                            </div>
                            {{-- <a href="http://localhost/sawari/about" style="background: #fff;color:black" class="read-more">Read More</a> --}}
                        </div>
                    </div>

    </div>
</section>
