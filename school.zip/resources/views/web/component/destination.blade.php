

<!-- top destination start here -->
<section class="top-destination-area pt-100 pb-70">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<div class="section-title text-center">
					<h2>Top Destination</h2>
					<p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan </p>
				</div>
			</div>
		</div>
		<div class="row">
            @foreach ($destinations as $destination)
			<!-- single destination -->
			<div class="col-md-3 col-sm-3 col-xs-12">
				<figure>
					<a href="#"><img src="{{ asset('uploads/destinations/' . $destination->image) }}" alt="">
					</a>
					<figcaption>
						<a href="#" title=""><h4>{{ $destination->title }}</h4></a>
					</figcaption>
				</figure>
			</div>
			<!-- single destination -->
            @endforeach
		</div>
	</div>
</section>
<!-- top destination end here -->
