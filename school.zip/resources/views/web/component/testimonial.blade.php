



<!-- testimonial area start here -->
<section class="section-paddings testimonial-two">
    <div class="testimonial-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="section-title text-center">
                        <h2>Happy travellers</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit Etiam at ipsum at ligula vestibulum
                            sodales Sed luctus orci vel nibh aliquam laoreet Aenean accumsan .</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <!-- start top media -->
                    <div class="top-testimonial-image row slick-pagination">
                        <div class="carousel-images slider-nav-two col-sm-8 col-sm-offset-2">
                            @foreach ($testimonials as $testimonial)
                                <div>
                                    <span><img src="{{ asset('uploads/testimonials/' . $testimonial->image) }}" alt="1"
                                            class="img-responsive img-circle"></span>
                                </div>
                            @endforeach


                        </div>
                    </div><!-- end top media images -->

                    <!-- bottom testimonial message -->
                    <div class="block-text row">
                        <div class="carousel-text slider-for-two col-sm-8 col-sm-offset-2">
                            @foreach ($testimonials as $testimonial)
                                <div class="single-box">
                                    <p>{{ $testimonial->description }}
                                    </p>
                                    <div class="client-bio">
                                        <h3>{{ $testimonial->title }}</h3>
                                        <span>{{ $testimonial->subtitle }}</span>
                                    </div>

                                </div>
                            @endforeach


                        </div>
                    </div><!-- bottom testimonial message -->
                </div><!-- /.block-text -->
            </div>
        </div>
    </div>
</section><!-- testimonial area end here -->
