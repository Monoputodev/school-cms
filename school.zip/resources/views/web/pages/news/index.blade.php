@extends('web.app.app')
@section('main-body')
<div class="main-body">
@include('web.component.section-7')
</div>

@endsection

