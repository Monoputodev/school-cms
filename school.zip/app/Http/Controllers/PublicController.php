<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\Content;

use App\Models\Hero;
use App\Models\Notice;
use App\Models\Package;


class PublicController extends Controller
{
    public function index()
    {

        return view('web.app.app',);
    }

    public function dashboard()
    {
        return view('admin.pages.index');
    }

}