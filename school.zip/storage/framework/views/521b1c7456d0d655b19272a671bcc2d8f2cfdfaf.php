<section class="top-courses pt-110 pb-80">
    <div class="container">
        <div class="section-title text-center mb-55">
            <h1 class="uppercase">OUR Courses</h1>
            <div class="separator my mtb-15">
                <i class="icofont icofont-hat-alt"></i>
            </div>
        </div>
        <div class="row">


            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="single-course mb-30">
                        <a href="#"><img src="<?php echo e(asset('')); ?>uploads/courses/<?php echo e($course->image); ?>" alt=""></a>
                        <div class="single-coures-text">
                            <h3><a href="#"><?php echo e($course->name); ?></a></h3>
                            <p><?php echo e($course->description); ?></p>
                            <a href="<?php echo e(route('course.details',$course->id)); ?>">READ MORE</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\school\resources\views/web/component/section-3.blade.php ENDPATH**/ ?>