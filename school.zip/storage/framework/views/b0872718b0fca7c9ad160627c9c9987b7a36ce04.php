
<head>

    <!-- Meta Tags -->
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <meta name="description"
        content="Digital Marketing Agencies, SEO companies & Social Media specialists HTML5 Template" />
    <meta name="keywords" content="marketing,seo,ppc,mapping,linkbuilding,analytics,ads" />
    <meta name="author" content="ThemeMascot" />

    <!-- Page Title -->
    <title><?php echo e($content->website_name); ?></title>

    <!-- Favicon and Touch Icons -->
    <link href="images/favicon.png" rel="shortcut icon" type="image/png">
    <link href="images/apple-touch-icon.png" rel="icon">
    <link href="images/apple-touch-icon-72x72.png" rel="icon" sizes="72x72">
    <link href="images/apple-touch-icon-114x114.png" rel="icon" sizes="114x114">
    <link href="images/apple-touch-icon-144x144.png" rel="icon" sizes="144x144">

    <!-- Stylesheet -->
    <link href="<?php echo e(asset('/')); ?>/assets/web/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('/')); ?>/assets/web/css/jquery-ui.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('/')); ?>/assets/web/css/animate.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('/')); ?>/assets/web/css/css-plugin-collections.css" rel="stylesheet" />
    <!-- CSS | menuzord megamenu skins -->
    <link href="<?php echo e(asset('/')); ?>/assets/web/css/menuzord-megamenu.css" rel="stylesheet" />
    <link id="menuzord-menu-skins" href="<?php echo e(asset('/')); ?>/assets/web/css/menuzord-skins/menuzord-boxed.css"
        rel="stylesheet" />
    <!-- CSS | Main style file -->
    <link href="<?php echo e(asset('/')); ?>/assets/web/css/style-main.css" rel="stylesheet" type="text/css">
    <!-- CSS | Preloader Styles -->
    <link href="<?php echo e(asset('/')); ?>/assets/web/css/preloader.css" rel="stylesheet" type="text/css">
    <!-- CSS | Custom Margin Padding Collection -->
    <link href="<?php echo e(asset('/')); ?>/assets/web/css/custom-bootstrap-margin-padding.css" rel="stylesheet"
        type="text/css">
    <!-- CSS | Responsive media queries -->
    <link href="<?php echo e(asset('/')); ?>/assets/web/css/responsive.css" rel="stylesheet" type="text/css">
    <!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
    <!-- <link href="<?php echo e(asset('/')); ?>/assets/web/css/style.css" rel="stylesheet" type="text/css"> -->

    <!-- CSS | Theme Color -->
    <link href="<?php echo e(asset('/')); ?>/assets/web/css/colors/theme-skin-color-set1.css" rel="stylesheet" type="text/css">
    <!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
    <!-- <link href="<?php echo e(asset('/')); ?>/assets/web/css/style.css" rel="stylesheet" type="text/css"> -->
    <link href="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/css/settings.css" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/css/layers.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/css/navigation.css" rel="stylesheet"
        type="text/css" />

    <!-- external javascripts -->
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/jquery-2.2.4.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/jquery-ui.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/bootstrap.min.js"></script>
    <!-- JS | jquery plugin collection for this theme -->
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/jquery-plugin-collection.js"></script>

    <!-- Revolution Slider 5.x SCRIPTS -->
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/js/jquery.themepunch.tools.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/js/jquery.themepunch.revolution.min.js"></script>


</head>
<?php /**PATH C:\xampp\htdocs\school\resources\views/web/inc/head.blade.php ENDPATH**/ ?>