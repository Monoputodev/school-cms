
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Home page || <?php echo e($content->website_name); ?></title>
    <meta name="description" content="<?php echo e($content->website_description); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('')); ?>assets/web/images/favicon.png">

    <!-- All css files are included here. -->
    <!-- Bootstrap fremwork main css -->
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>assets/web/css/bootstrap.min.css">
    <!-- This core.css file contents all plugings css file. -->
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>assets/web/css/core.css">
    <!-- Theme shortcodes/elements style -->
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>assets/web/css/shortcode/shortcodes.css">
    <!-- Theme main style -->
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>assets/web/css/style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>assets/web/css/responsive.css">
    <!-- Style customizer (Remove these two lines please) -->
    <link rel="stylesheet" href="<?php echo e(asset('')); ?>assets/web/css/style-customizer.css">
    <link href="#" data-style="styles" rel="stylesheet">

    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/vendor/modernizr-3.11.7.min.js"></script>
</head>
<?php /**PATH C:\xampp\htdocs\school\resources\views/web/inc/head.blade.php ENDPATH**/ ?>