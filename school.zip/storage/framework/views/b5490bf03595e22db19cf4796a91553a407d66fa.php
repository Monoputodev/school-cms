<header id="header" class="header">
    <div class="container">
        <div class="header-nav">
            <div class="header-nav-wrapper navbar-scrolltofixed bg-white">
                    <div class="row">
                        <div class="col-md-12">
                            <img src="<?php echo e(asset('')); ?>assets/web/top.jpg" class="top-img img-fluid " style="width: 100%" alt="">
                        </div>
                        <div class="col-md-12">
                            <nav id="menuzord-right" class="menuzord default no-bg" style="
                            text-align: center;
                            display: flex;
                            justify-content: center;
                        ">
                        <ul class="menuzord-menu onepage-nav ">
                            <li class="active"><a href="#home">Home</a></li>
                            <li><a href="#about">Adnission Online</a></li>
                            <li><a href="#about">Notice</a></li>
                            <li><a href="#about">About</a></li>
                            <li><a href="#team">Teachers</a></li>
                            <li><a href="#blog">News</a></li>
                            
                        </ul>
                    </nav>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</header>
<?php /**PATH C:\xampp\htdocs\school-cms\resources\views/web/inc/header.blade.php ENDPATH**/ ?>