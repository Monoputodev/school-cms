<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php echo $__env->make('web.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="has-side-panel side-panel-right fullwidth-page">
    <div class="body-overlay"></div>
    <?php echo $__env->make('web.inc.side-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="wrapper">


        <!-- Header -->
        <?php echo $__env->make('web.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Start main-content -->
        <div class="main-content">
            <?php if($massage = Session::get('success')): ?>

          <?php endif; ?>
<?php echo $__env->yieldContent('main-body'); ?>

        </div>
        <!-- end main-content -->

        <!-- Footer -->
        
        <a class="scrollToTop" href="#"><i class="flaticon-seo-transport-3"></i></a>
    </div>
<?php echo $__env->make('web.inc.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\school-cms\resources\views/web/app/app.blade.php ENDPATH**/ ?>