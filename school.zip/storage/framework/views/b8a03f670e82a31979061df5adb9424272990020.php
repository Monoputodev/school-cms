<?php $__env->startSection('main-body'); ?>
<div class="main-body">
<?php echo $__env->make('web.component.section-7', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/web/pages/news/index.blade.php ENDPATH**/ ?>