<?php $__env->startSection('main-body'); ?>
    <div class="main-body">

        <section class="breadcrumbs-area bg-3 ptb-110 bg-opacity bg-relative">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="breadcrumbs">
                            <h2 class="page-title"><?php echo e($cat->name); ?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>



        <div class="upcoming-event-area pt-110 pb-70">
            <div class="container">
                <div class="section-title text-center mb-55">
                    <h1 class="uppercase"><?php echo e($cat->name); ?></h1>
                    <div class="separator my mtb-15">
                        <i class="icofont icofont-hat-alt"></i>
                    </div>
                </div>
                <div class="all-upcoming-event">
                    <div class="row">

                        <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6 col-md-12">
                                <div class="single-upcoming mb-40">
                                    <div class="upcoming-date text-center">
                                        <div class="date-all">
                                            <span><?php echo e($notice->created_at->format('d')); ?></span>
                                            <span class="month"><?php echo e($notice->created_at->format('M y')); ?></span>
                                        </div>
                                    </div>
                                    <div class="single-upcoming-text">
                                        <div class="blog-meta">
                                            <span class="published3">
                                                <i class="fa fa-clock-o" aria-hidden="true"></i>
                                                <?php echo e($notice->created_at->format('h:i a')); ?>

                                            </span>
                                            <span class="published4">
                                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                                                <?php echo e($content->website_name); ?>

                                            </span>
                                        </div>
                                        <h3><a href="#"><?php echo e($notice->title); ?></a></h3>
                                        <p><?php echo e($notice->subtitle); ?></p>
                                        <?php if($notice->pdf_file): ?>
                                            <a href="<?php echo e(asset('')); ?>uploads/notices/<?php echo e($notice->pdf_file); ?>"
                                                target="_blank" rel="noopener noreferrer" class="btn btn-primary">Download
                                                file</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/web/pages/notice/details.blade.php ENDPATH**/ ?>