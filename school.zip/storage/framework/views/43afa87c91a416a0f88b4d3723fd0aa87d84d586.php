<!-- start categoris area -->
<div class="notice-area  ">
    <div class="section-title text-center mb-10 mt-30">
        <h1 class="uppercase">Leatest Notice</h1>
        <div class="separator my mtb-15">
            <i class="icofont icofont-hat-alt"></i>
        </div>
    </div>
    <marquee behavior="scroll" direction="left" class="pt-10 pb-10 bg-dark text-white" scrollamount="5">
        <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span style="font-size: 18px"><a href=""> <span class="font-weight-bold text-info ml-10 mr-10" ><?php echo e($notice->created_at->format('d  M Y')); ?></span> : <?php echo e($notice->title); ?></a> <i class="fas fa-search"></i></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </marquee>
    <?php if(request()->routeIs('index')): ?>
<a href="<?php echo e(route('notice.index')); ?>" class="mx-0auto text-center btn btn-dark btn-sm">View All</a>
<?php endif; ?>
</div>


<?php /**PATH C:\xampp\htdocs\school\resources\views/web/component/section-2.blade.php ENDPATH**/ ?>