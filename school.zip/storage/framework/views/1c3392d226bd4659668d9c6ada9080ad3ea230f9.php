      <div class="container">
        <div class="row">
            <div class="col-sm-10">
                <!-- Start of slider area -->
                <div class="slider-area">
                    <div class="slider-active">
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="slider-all">
                            <img src="<?php echo e(asset('')); ?>uploads/hero/<?php echo e($slider->image); ?>" alt="">

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <!-- End of slider area -->
            </div>
            <div class="col-sm-2"></div>
        </div>
      </div>
<?php /**PATH C:\xampp\htdocs\school\resources\views/web/component/section-1.blade.php ENDPATH**/ ?>