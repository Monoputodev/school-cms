


<?php $__env->startSection('main-body'); ?>
    <div class="main-body">
            <!-- Section: home -->
            <?php echo $__env->make('web.component.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Section: About  -->
            <?php echo $__env->make('web.component.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            <!-- Section: free-registration  -->
            <?php echo $__env->make('web.component.querry', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            


            <!-- Section: -->


            <!-- Section:  -->
            <?php echo $__env->make('web.component.team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Divider: -->
<?php echo $__env->make('web.component.divider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Section: blog -->
            <?php echo $__env->make('web.component.news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Divider: Reservation Form -->
<?php echo $__env->make('web.component.contact-us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school-cms\resources\views/web/pages/index.blade.php ENDPATH**/ ?>