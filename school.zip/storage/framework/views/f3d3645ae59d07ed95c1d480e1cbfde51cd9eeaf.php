    <!-- jquery latest version -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/vendor/jquery-v1.12.4.min.js"></script>
    <!-- Bootstrap framework js -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/popper.min.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/bootstrap.min.js"></script>
    <!--  ajax-mail.js  -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/ajax-mail.js"></script>
    <!-- All js plugins included in this file. -->
    <script src="<?php echo e(asset('')); ?>assets/web/js/plugins.js"></script>
    <script src="<?php echo e(asset('')); ?>assets/web/js/main.js"></script>
<?php /**PATH C:\xampp\htdocs\school\resources\views/web/inc/script.blade.php ENDPATH**/ ?>