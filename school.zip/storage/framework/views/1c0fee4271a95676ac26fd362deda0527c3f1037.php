<section id="team">
	<div class="container pb-sm-70">
		<div class="section-title text-center">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2">
					<h2 class="mt-0 line-height-1">Faculty <span
							class="text-theme-colored3">Members</span></h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Acque quidem eaque, amet
						doloribus, error inventore, quisquam totam magni cumque.</p>
				</div>
			</div>
		</div>
		<div class="section-content text-center">
			<div class="row">
				<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-sm-6 col-md-3 mb-sm-30">
					<div class="team-block bg-light pt-10 pb-15">
						<div class="team-thumb"><img class="img-fullwidth"
								src="<?php echo e(asset('/')); ?>uploads/teams/<?php echo e($team->image); ?>" alt="">
						</div>
						<div class="info">
							<div class="pt-10 pb-10 bg-theme-colored2">
								<h4 class="mt-0 mb-0 text-white"><?php echo e($team->name); ?></h4>
								<h6 class="mt-0 mb-0 text-white"><?php echo e($team->designation); ?></h6>
							</div>

						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				

			</div>
		</div>
	</div>
</section><?php /**PATH C:\xampp\htdocs\school-cms\resources\views/web/component/team.blade.php ENDPATH**/ ?>