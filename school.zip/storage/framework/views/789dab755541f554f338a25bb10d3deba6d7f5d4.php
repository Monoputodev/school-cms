<?php $__env->startSection('main-body'); ?>
<div class="main-body">
    <section class="breadcrumbs-area bg-3 ptb-110 bg-opacity bg-relative">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="breadcrumbs">
                            <h2 class="page-title"><?php echo e($course->name); ?></h2>
                            <ul>
                                <li>
                                    <a class="active" href="#">Home</a>
                                </li>
                                <li>
                                    <a>Course</a>
                                </li>
                                <li>Courses Details</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <section class="courses-details pt-110 pb-80">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8">
                    <div class="course-left-sidebar">
                        <h3 class="sidebar-title"><?php echo e($course->name); ?></h3>
                        <div class="course-details-img">
                            <img alt="" src="<?php echo e(asset('')); ?>uploads/courses/<?php echo e($course->image); ?>">

                            <div class="free-area pt-30">
                                <div class="free-text">
<?php echo $course->description; ?>

                                </div>

                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-lg-4 col-md-4">
                    <div class="course-sidebar mrg-xs">
                        <div class="course-categoris">
                            <h3 class="cate-title">Courses</h3>
                            <ul>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li><a href="<?php echo e(route('course.details',$item->id)); ?>">P<?php echo e($item->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/web/pages/course/details.blade.php ENDPATH**/ ?>