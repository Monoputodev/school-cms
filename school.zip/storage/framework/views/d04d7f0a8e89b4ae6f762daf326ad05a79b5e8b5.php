<?php $__env->startSection('main-body'); ?>
    <div class="main-body">
        <section class="breadcrumbs-area bg-3 ptb-110 bg-opacity bg-relative">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <div class="breadcrumbs">
                            <h2 class="page-title"><?php echo e($news->title); ?></h2>
                            <ul>
                                <li>
                                    <a class="active" href="#">Home</a>
                                </li>
                                <li>
                                    <a>News</a>
                                </li>
                                <li><?php echo e($news->title); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="news-details-area pt-110">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="news-details-all gray-bg">
                            <img src="<?php echo e(asset('')); ?>uploads/blogs/<?php echo e($news->image); ?>" alt="">
                            <div class="news-details-all-area pt-40 pl-200 pr-200">
                                <div class="news-details-top">
                                    <h3><?php echo e($news->title); ?> </h3>
                                    <div class="news-details-calender">
                                        <div class="blog-meta-2">
                                            <span class="published3">
                                                <i class="icofont icofont-ui-calendar"></i>
                                                <?php echo e($news->created_at->format('d M Y')); ?>

                                            </span>
                                        </div>

                                    </div>
                                </div>
                                <div class="news-details-middle">
                                    <?php echo $news->description; ?>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/web/pages/news/details.blade.php ENDPATH**/ ?>