<?php $__env->startSection('main-body'); ?>
<div class="main-body">
    <section class="breadcrumbs-area bg-3 ptb-110 bg-opacity bg-relative">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumbs">
                        <h2 class="page-title">Teachers</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('web.component.section-6', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('web.app.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\school\resources\views/web/pages/teacher/index.blade.php ENDPATH**/ ?>