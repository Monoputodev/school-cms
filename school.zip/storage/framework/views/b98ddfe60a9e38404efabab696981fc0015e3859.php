<section id="reservation" class="bg-silver-light">
    <div class="container pt-sm-30 pb-sm-50">
        <div class="section-title text-center">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12">
                    <h2 class="mt-0 line-height-1 text-center">Contact <span
                            class="text-theme-colored3">Us</span></h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem temporibus
                        quisquam voluptas natus, provident porro et odio perferendis ipsam, amet sint</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8">
                <div class="mt-10 mt-sm-40">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24553.887820774053!2d90.4792693090543!3d23.82011873731961!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c9c853f1cccb%3A0xe769ce292497166c!2sDhaka%20City%20College%2C%20Purbachal%20Branch!5e0!3m2!1sen!2sbd!4v1685187189020!5m2!1sen!2sbd" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row">
                    <div class="col-sm-6 col-md-12">
                        <div class="icon-box icon-left iconbox-theme-colored">
                            <a class="icon icon-gray icon-circled icon-border-effect effect-circled icon-sm pull-left flip"
                                href="#">
                                <i class="fa fa-phone-square"></i>
                            </a>
                            <h4 class="icon-box-title mb-5">Call us today!</h4>
                            <p class="text-gray"><?php echo e($content->website_phone); ?></p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-12">
                        <div class="icon-box icon-left iconbox-theme-colored">
                            <a class="icon icon-gray icon-circled icon-border-effect effect-circled icon-sm pull-left flip"
                                href="#">
                                <i class="fa fa-envelope"></i>
                            </a>
                            <h5 class="icon-box-title mb-5">Mail Us</h5>
                            <p class="text-gray"><?php echo e($content->website_email); ?></p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-12">
                        <div class="icon-box icon-left iconbox-theme-colored">
                            <a class="icon icon-gray icon-circled icon-border-effect effect-circled icon-sm pull-left flip"
                                href="#">
                                <i class="fa fa-map-marker"></i>
                            </a>
                            <h4 class="icon-box-title mb-5">Location</h4>
                            <p class="text-gray"><?php echo e($content->website_address); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\school-cms\resources\views/web/component/contact-us.blade.php ENDPATH**/ ?>