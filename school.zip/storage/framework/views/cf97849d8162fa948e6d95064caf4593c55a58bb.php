
<header class="header-area">
    <div class="header-top blue-bg">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-7 col-12">
                    <div class="header-top-info">
                        <ul>
                            <li>
                                <a href="#">
                                    <i class="zmdi zmdi-phone"></i>
                                </a>
                                <?php echo e($content->website_phone); ?>

                            </li>
                            <li>
                                <a href="#">
                                    <i class="zmdi zmdi-globe"></i>
                                    <?php echo e($content->website_email); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="header-bottom stick-h2">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-12 col-12">
                    <div class="logo">
                        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('')); ?>uploads/content/<?php echo e($content->website_logo); ?>" alt=""> </a>
                    </div>
                </div>
                <div class="col-md-8 hidden-sm d-none d-md-block">
                    <div class="menu-area f-right">
                        <nav>
                            <ul>
                                <li><a href="<?php echo e(route('index')); ?>">Home  </a></li>
                                <li class="active coloumn-one"><a href="index.html">Notice <i class="zmdi zmdi-caret-down"></i></a>
                                    <ul>
                                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e(route('notice.details',$type->id)); ?>"><?php echo e($type->name); ?></a></li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </li>

                                <li><a href="<?php echo e(route('teacher.index')); ?>">Teachers  </a></li>
                                <li><a href="<?php echo e(route('course.index')); ?>">Our Programme  </a></li>
                                <li><a href="<?php echo e(route('news.index')); ?>">NEWS  </a></li>
                                <li><a class="none-padding" href="contact.html">CONTACT </a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\school\resources\views/web/inc/header.blade.php ENDPATH**/ ?>