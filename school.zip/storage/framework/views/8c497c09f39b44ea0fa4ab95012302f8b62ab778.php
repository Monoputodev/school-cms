<!DOCTYPE html>
<html dir="ltr" lang="en">
<?php echo $__env->make('web.inc.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="has-side-panel side-panel-right fullwidth-page">
    <div class="body-overlay"></div>
    <?php echo $__env->make('web.inc.side-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="wrapper">
        <!-- preloader -->
        <div id="preloader">
            <div id="spinner">
                <div class="preloader-dot-loading">
                    <div class="cssload-loading"><i></i><i></i><i></i><i></i></div>
                </div>
            </div>
            <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
        </div>

        <!-- Header -->
<?php echo $__env->make('web.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Start main-content -->
        <div class="main-content">
            <!-- Section: home -->
            <section id="home" class="divider">
                <div class="container-fluid p-0">

                    <!-- START REVOLUTION SLIDER 5.0.7 -->
                    <div id="rev_slider_home_wrapper" class="rev_slider_wrapper fullwidthbanner-container"
                        data-alias="news-gallery34"
                        style="margin:0px auto;background-color:#ffffff;padding:0px;margin-top:0px;margin-bottom:0px;">
                        <!-- START REVOLUTION SLIDER 5.0.7 fullwidth mode -->
                        <div id="rev_slider_home" class="rev_slider fullwidthabanner" style="display:none;"
                            data-version="5.0.7">
                            <ul>
                                <!-- SLIDE 1 -->
                                <li data-index="rs-1" data-transition="slidingoverlayhorizontal"
                                    data-slotamount="default" data-easein="default" data-easeout="default"
                                    data-masterspeed="default" data-thumb="images/bg/bg5.jpg" data-rotate="0"
                                    data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7"
                                    data-saveperformance="off" data-title="Make an Impact">
                                    <!-- MAIN IMAGE -->
                                    <img src="<?php echo e(asset('/')); ?>/assets/web/images/bg/bg5.jpg" alt=""
                                        data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat"
                                        data-bgparallax="10" class="rev-slidebg" data-no-retina>
                                    <!-- LAYERS -->
                                    <!-- LAYER NR. 1 -->
                                    <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme rs-parallaxlevel-0"
                                        id="slide-1-layer-1" data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['0','0','0','0']" data-width="full" data-height="full"
                                        data-whitespace="normal" data-transform_idle="o:1;"
                                        data-transform_in="opacity:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                                        data-start="1000" data-basealign="slide" data-responsive_offset="on"
                                        style="z-index: 5;background-color:rgba(0, 0, 0, 0.5);border-color:rgba(0, 0, 0, 1.00);">
                                    </div>
                                    <!-- LAYER NR. 2 -->
                                    <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0"
                                        id="slide-1-layer-2" data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']"
                                        data-voffset="['200','195','160','150']" data-fontsize="['60','50','40','35']"
                                        data-lineheight="['80','75','70','45']"
                                        data-fontweight="['800','700','700','700']"
                                        data-textalign="['center','center','center','center']"
                                        data-width="['800','650','600','420']" data-height="none"
                                        data-whitespace="normal" data-transform_idle="o:1;"
                                        data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"
                                        data-mask_in="x:0px;y:0px;s:inherit;e:inherit;"
                                        data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000"
                                        data-splitin="none" data-splitout="none" data-responsive_offset="on"
                                        style="z-index: 6; min-width: 600px; max-width: 600px; white-space: normal;">
                                        Our Best <span class="text-theme-colored2">Study</span> Institute
                                    </div>
                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0"
                                        id="slide-1-layer-3" data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']"
                                        data-voffset="['290','260','220','220']" data-fontsize="['16','16',16',16']"
                                        data-lineheight="['24','24','24','24']"
                                        data-fontweight="['400','400','400','400']"
                                        data-textalign="['center','center','center','center']"
                                        data-width="['800','650','600','460']" data-height="none"
                                        data-whitespace="nowrap" data-transform_idle="o:1;"
                                        data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"
                                        data-mask_in="x:0px;y:0px;s:inherit;e:inherit;"
                                        data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="700"
                                        data-splitin="none" data-splitout="none" data-responsive_offset="on"
                                        style="z-index: 5; white-space: nowrap;">EduPoints is a international leader in
                                        teaching students to write effectively,<br> learn from each other and think for
                                        themselves.
                                    </div>
                                    <!-- LAYER NR. 4 -->
                                    <div class="tp-caption rs-parallaxlevel-0" id="slide-1-layer-4"
                                        data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']"
                                        data-voffset="['361','321','281','295']" data-width="none" data-height="none"
                                        data-whitespace="nowrap" data-transform_idle="o:1;"
                                        data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"
                                        data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"
                                        data-mask_in="x:0px;y:0px;" data-mask_out="x:0;y:0;" data-start="1000"
                                        data-splitin="none" data-splitout="none" data-responsive_offset="on"
                                        data-responsive="off"
                                        style="z-index: 8; white-space: nowrap;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">
                                        <a href="#" class="btn btn-dark btn-theme-colored btn-lg">Help Save
                                            Acres</a> <a href="#"
                                            class="btn btn-dark btn-theme-colored btn-lg">Join Us</a>
                                    </div>
                                </li>

                                <!-- SLIDE 2 -->
                                <li data-index="rs-2" data-transition="slidingoverlayhorizontal"
                                    data-slotamount="default" data-easein="default" data-easeout="default"
                                    data-masterspeed="default" data-thumb="images/bg/bg2.jpg" data-rotate="0"
                                    data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7"
                                    data-saveperformance="off" data-title="Make an Impact">
                                    <!-- MAIN IMAGE -->
                                    <img src="<?php echo e(asset('/')); ?>/assets/web/images/bg/bg2.jpg" alt=""
                                        data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat"
                                        data-bgparallax="10" class="rev-slidebg" data-no-retina>
                                    <!-- LAYERS -->
                                    <!-- LAYER NR. 1 -->
                                    <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme rs-parallaxlevel-0"
                                        id="slide-2-layer-1" data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['0','0','0','0']" data-width="full" data-height="full"
                                        data-whitespace="normal" data-transform_idle="o:1;"
                                        data-transform_in="opacity:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                                        data-start="1000" data-basealign="slide" data-responsive_offset="on"
                                        style="z-index: 5;background-color:rgba(0, 0, 0, 0.5);border-color:rgba(0, 0, 0, 1.00);">
                                    </div>
                                    <!-- LAYER NR. 2 -->
                                    <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0"
                                        id="slide-2-layer-2" data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']"
                                        data-voffset="['200','195','160','160']" data-fontsize="['60','50','40','35']"
                                        data-lineheight="['80','75','70','45']"
                                        data-fontweight="['800','700','700','700']"
                                        data-textalign="['center','center','center','center']"
                                        data-width="['800','650','600','420']" data-height="none"
                                        data-whitespace="normal" data-transform_idle="o:1;"
                                        data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"
                                        data-mask_in="x:0px;y:0px;s:inherit;e:inherit;"
                                        data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000"
                                        data-splitin="none" data-splitout="none" data-responsive_offset="on"
                                        style="z-index: 6; min-width: 600px; max-width: 600px; white-space: normal;">
                                        Welcome To <span class="text-theme-colored2">EduPonits</span>
                                    </div>
                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0"
                                        id="slide-2-layer-3" data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']"
                                        data-voffset="['290','260','220','220']" data-fontsize="['16','16',16',16']"
                                        data-lineheight="['24','24','24','24']"
                                        data-fontweight="['400','400','400','400']"
                                        data-textalign="['center','center','center','center']"
                                        data-width="['800','650','600','460']" data-height="none"
                                        data-whitespace="nowrap" data-transform_idle="o:1;"
                                        data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"
                                        data-mask_in="x:0px;y:0px;s:inherit;e:inherit;"
                                        data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="700"
                                        data-splitin="none" data-splitout="none" data-responsive_offset="on"
                                        style="z-index: 5; white-space: nowrap;">EduPoints is a international leader in
                                        teaching students to write effectively,<br> learn from each other and think for
                                        themselves.
                                    </div>
                                    <!-- LAYER NR. 4 -->
                                    <div class="tp-caption rs-parallaxlevel-0" id="slide-2-layer-4"
                                        data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']"
                                        data-voffset="['361','321','281','295']" data-width="none" data-height="none"
                                        data-whitespace="nowrap" data-transform_idle="o:1;"
                                        data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"
                                        data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"
                                        data-mask_in="x:0px;y:0px;" data-mask_out="x:0;y:0;" data-start="1000"
                                        data-splitin="none" data-splitout="none" data-responsive_offset="on"
                                        data-responsive="off"
                                        style="z-index: 8; white-space: nowrap;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">
                                        <a href="#" class="btn btn-dark btn-theme-colored btn-lg">Help Save
                                            Acres</a> <a href="#"
                                            class="btn btn-dark btn-theme-colored btn-lg">Join Us</a>
                                    </div>
                                </li>

                                <!-- SLIDE 3 -->
                                <li data-index="rs-3" data-transition="slidingoverlayhorizontal"
                                    data-slotamount="default" data-easein="default" data-easeout="default"
                                    data-masterspeed="default" data-thumb="images/bg/bg3.jpg" data-rotate="0"
                                    data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7"
                                    data-saveperformance="off" data-title="Make an Impact">
                                    <!-- MAIN IMAGE -->
                                    <img src="<?php echo e(asset('/')); ?>/assets/web/images/bg/bg3.jpg" alt=""
                                        data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat"
                                        data-bgparallax="10" class="rev-slidebg" data-no-retina>
                                    <!-- LAYERS -->
                                    <!-- LAYER NR. 1 -->
                                    <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme rs-parallaxlevel-0"
                                        id="slide-3-layer-1" data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']"
                                        data-y="['middle','middle','middle','middle']"
                                        data-voffset="['0','0','0','0']" data-width="full" data-height="full"
                                        data-whitespace="normal" data-transform_idle="o:1;"
                                        data-transform_in="opacity:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="opacity:0;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"
                                        data-start="1000" data-basealign="slide" data-responsive_offset="on"
                                        style="z-index: 5;background-color:rgba(0, 0, 0, 0.55);border-color:rgba(0, 0, 0, 1.00);">
                                    </div>
                                    <!-- LAYER NR. 2 -->
                                    <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0"
                                        id="slide-3-layer-2" data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']"
                                        data-voffset="['200','195','160','130']" data-fontsize="['60','50','40','35']"
                                        data-lineheight="['80','75','70','45']"
                                        data-fontweight="['800','700','700','700']"
                                        data-textalign="['center','center','center','center']"
                                        data-width="['800','650','600','420']" data-height="none"
                                        data-whitespace="normal" data-transform_idle="o:1;"
                                        data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"
                                        data-mask_in="x:0px;y:0px;s:inherit;e:inherit;"
                                        data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000"
                                        data-splitin="none" data-splitout="none" data-responsive_offset="on"
                                        style="z-index: 6; min-width: 600px; max-width: 600px; white-space: normal;">
                                        Best <span class="text-theme-colored2">Online</span> Certification
                                    </div>
                                    <!-- LAYER NR. 3 -->
                                    <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0"
                                        id="slide-3-layer-3" data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']"
                                        data-voffset="['290','260','220','220']" data-fontsize="['16','16',16',16']"
                                        data-lineheight="['24','24','24','24']"
                                        data-fontweight="['400','400','400','400']"
                                        data-textalign="['center','center','center','center']"
                                        data-width="['800','650','600','460']" data-height="none"
                                        data-whitespace="nowrap" data-transform_idle="o:1;"
                                        data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"
                                        data-mask_in="x:0px;y:0px;s:inherit;e:inherit;"
                                        data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="700"
                                        data-splitin="none" data-splitout="none" data-responsive_offset="on"
                                        style="z-index: 5; white-space: nowrap;">EduPoints is a international leader in
                                        teaching students to write effectively,<br> learn from each other and think for
                                        themselves.
                                    </div>
                                    <!-- LAYER NR. 4 -->
                                    <div class="tp-caption rs-parallaxlevel-0" id="slide-3-layer-4"
                                        data-x="['center','center','center','center']"
                                        data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']"
                                        data-voffset="['361','321','281','295']" data-width="none" data-height="none"
                                        data-whitespace="nowrap" data-transform_idle="o:1;"
                                        data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:300;e:Power1.easeInOut;"
                                        data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                                        data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;"
                                        data-mask_in="x:0px;y:0px;" data-mask_out="x:0;y:0;" data-start="1000"
                                        data-splitin="none" data-splitout="none" data-responsive_offset="on"
                                        data-responsive="off"
                                        style="z-index: 8; white-space: nowrap;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;">
                                        <a href="#" class="btn btn-dark btn-theme-colored btn-lg">Help Save
                                            Acres</a> <a href="#"
                                            class="btn btn-dark btn-theme-colored btn-lg">Join Us</a>
                                    </div>
                                </li>
                            </ul>
                            <div class="tp-bannertimer tp-bottom"
                                style="height: 5px; background-color: rgba(166, 216, 236, 1.00);"></div>
                        </div>
                    </div>

                    <!-- END REVOLUTION SLIDER -->
                    <script>
                        var tpj = jQuery;
                        var revapi34;
                        tpj(document).ready(function() {
                            if (tpj("#rev_slider_home").revolution == undefined) {
                                revslider_showDoubleJqueryError("#rev_slider_home");
                            } else {
                                revapi34 = tpj("#rev_slider_home").show().revolution({
                                    sliderType: "standard",
                                    jsFileLocation: "js/revolution-slider/js/",
                                    sliderLayout: "fullwidth",
                                    dottedOverlay: "none",
                                    delay: 9000,
                                    navigation: {
                                        keyboardNavigation: "on",
                                        keyboard_direction: "horizontal",
                                        mouseScrollNavigation: "off",
                                        onHoverStop: "on",
                                        touch: {
                                            touchenabled: "on",
                                            swipe_threshold: 75,
                                            swipe_min_touches: 1,
                                            swipe_direction: "horizontal",
                                            drag_block_vertical: false
                                        },
                                        arrows: {
                                            style: "zeus",
                                            enable: true,
                                            hide_onmobile: true,
                                            hide_under: 600,
                                            hide_onleave: true,
                                            hide_delay: 200,
                                            hide_delay_mobile: 1200,
                                            tmp: '<div class="tp-title-wrap">    <div class="tp-arr-imgholder"></div> </div>',
                                            left: {
                                                h_align: "left",
                                                v_align: "center",
                                                h_offset: 30,
                                                v_offset: 0
                                            },
                                            right: {
                                                h_align: "right",
                                                v_align: "center",
                                                h_offset: 30,
                                                v_offset: 0
                                            }
                                        },
                                        bullets: {
                                            enable: true,
                                            hide_onmobile: true,
                                            hide_under: 600,
                                            style: "metis",
                                            hide_onleave: true,
                                            hide_delay: 200,
                                            hide_delay_mobile: 1200,
                                            direction: "horizontal",
                                            h_align: "center",
                                            v_align: "bottom",
                                            h_offset: 0,
                                            v_offset: 30,
                                            space: 5,
                                            tmp: '<span class="tp-bullet-img-wrap"><span class="tp-bullet-image"></span></span>'
                                        }
                                    },
                                    viewPort: {
                                        enable: true,
                                        outof: "pause",
                                        visible_area: "80%"
                                    },
                                    responsiveLevels: [1240, 1024, 778, 480],
                                    gridwidth: [1240, 1024, 778, 480],
                                    gridheight: [750, 550, 500, 450],
                                    lazyType: "none",
                                    parallax: {
                                        type: "scroll",
                                        origo: "enterpoint",
                                        speed: 400,
                                        levels: [5, 10, 15, 20, 25, 30, 35, 40, 45, 50],
                                    },
                                    shadow: 0,
                                    spinner: "off",
                                    stopLoop: "off",
                                    stopAfterLoops: -1,
                                    stopAtSlide: -1,
                                    shuffle: "off",
                                    autoHeight: "off",
                                    hideThumbsOnMobile: "off",
                                    hideSliderAtLimit: 0,
                                    hideCaptionAtLimit: 0,
                                    hideAllCaptionAtLilmit: 0,
                                    debugMode: false,
                                    fallbacks: {
                                        simplifyAll: "off",
                                        nextSlideOnWindowFocus: "off",
                                        disableFocusListener: false,
                                    }
                                });
                            }
                        }); /*ready*/
                    </script>
                    <!-- END REVOLUTION SLIDER -->
                </div>
            </section>

            <!-- Section: About  -->
            <section id="about">
                <div class="container pb-90 pb-sm-90">
                    <div class="section-content">
                        <div class="row">
                            <div class="col-sm-6 col-md-8">
                                <h2 class="mt-0 mt-sm-30 line-height-1 line-bottom-edu">Welcome to <span
                                        class="text-theme-colored3">EduPoints</span></h2>

                                <div class="box-hover-effect play-button">
                                    <div class="effect-wrapper">
                                        <div class="thumb mb-20">
                                            <img class="img-fullwidth"
                                                src="<?php echo e(asset('/')); ?>/assets/web/images/about/6.jpg"
                                                alt="project">
                                        </div>
                                        <div class="text-holder text-holder-middle">
                                            <a href="https://www.youtube.com/watch?v=F3QpgXBtDeo"
                                                data-lightbox-gallery="youtube-video" title="Youtube Video"><img
                                                    alt=""
                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/play-button/s14.png"></a>
                                        </div>
                                    </div>
                                </div>
                                <p class="font-15">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis
                                    aliquam pellentesque erat nec ultricies. Ut lobortis, magna nec rhoncus vestibulum,
                                    neque quam mattis ipsum, vel bibendum erat</p>
                                <p class="font-15">Suspendisse dui enim, vehicula ac tempus sed, ullamcorper pretium
                                    mauris. Ut vel pellentesque felis, sit amet laoreet sem. Nunc lacinia mauris a felis
                                    tincidunt ullamcorper.</p>
                                <a class="btn btn-colored btn-lg btn-theme-colored mt-15 mb-sm-30"
                                    href="page-about1.html">Read more</a>
                            </div>
                            <div class="col-sm-6 col-md-4">
                                <h2 class="mt-0 mb-40 mt-xs-20 line-height-1">Get Event</h2>
                                <div class="bxslider bx-nav-top" data-minslides="6">
                                    <div class="event media mt-0 no-bg no-border">
                                        <div class="event-date media-left text-center flip bg-theme-colored pl-10">
                                            <ul class="mt-15 mt-sm-30">
                                                <li class="font-20 text-white font-weight-600">28</li>
                                                <li class="font-14 text-uppercase text-white">Feb</li>
                                            </ul>
                                        </div>
                                        <div class="media-body">
                                            <div class="event-content pull-left flip pl-20 pl-xs-10">
                                                <h4
                                                    class="event-title media-heading font-raleway font-weight-700 mb-0 pt-5">
                                                    <a href="#">Gear up for giving</a></h4>
                                                <span class="mb-5 font-12 mr-10"><i
                                                        class="fa fa-clock-o mr-5 text-theme-colored"></i> at 5.00 pm -
                                                    7.30 pm</span>
                                                <span class="font-12"><i
                                                        class="fa fa-map-marker mr-5 text-theme-colored"></i> 25
                                                    Newyork City</span>
                                                <p class="mb-5">Lorem ipsum dolor sit amet</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="event media mt-0 no-bg no-border">
                                        <div class="event-date media-left text-center flip bg-theme-colored2 p-10">
                                            <ul class="mt-5 mt-sm-20">
                                                <li class="font-20 text-white font-weight-600">28</li>
                                                <li class="font-14 text-uppercase text-white">Feb</li>
                                            </ul>
                                        </div>
                                        <div class="media-body">
                                            <div class="event-content pull-left flip pl-20 pl-xs-10">
                                                <h4
                                                    class="event-title media-heading font-raleway font-weight-700 mb-0 pt-5">
                                                    <a href="#">Gear up for giving</a></h4>
                                                <span class="mb-5 font-12 mr-10"><i
                                                        class="fa fa-clock-o mr-5 text-theme-colored"></i> at 5.00 pm -
                                                    7.30 pm</span>
                                                <span class="font-12"><i
                                                        class="fa fa-map-marker mr-5 text-theme-colored"></i> 25
                                                    Newyork City</span>
                                                <p class="mb-5">Lorem ipsum dolor sit amet</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="event media mt-0 no-bg no-border">
                                        <div class="event-date media-left text-center flip bg-theme-colored3 p-10">
                                            <ul class="mt-5 mt-sm-20">
                                                <li class="font-20 text-white font-weight-600">28</li>
                                                <li class="font-14 text-uppercase text-white">Feb</li>
                                            </ul>
                                        </div>
                                        <div class="media-body">
                                            <div class="event-content pull-left flip pl-20 pl-xs-10">
                                                <h4
                                                    class="event-title media-heading font-raleway font-weight-700 mb-0 pt-5">
                                                    <a href="#">Gear up for giving</a></h4>
                                                <span class="mb-5 font-12 mr-10"><i
                                                        class="fa fa-clock-o mr-5 text-theme-colored"></i> at 5.00 pm -
                                                    7.30 pm</span>
                                                <span class="font-12"><i
                                                        class="fa fa-map-marker mr-5 text-theme-colored"></i> 25
                                                    Newyork City</span>
                                                <p class="mb-5">Lorem ipsum dolor sit amet</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="event media mt-0 no-bg no-border">
                                        <div class="event-date media-left text-center flip bg-theme-colored p-10">
                                            <ul class="mt-5 mt-sm-20">
                                                <li class="font-20 text-white font-weight-600">28</li>
                                                <li class="font-14 text-uppercase text-white">Feb</li>
                                            </ul>
                                        </div>
                                        <div class="media-body">
                                            <div class="event-content pull-left flip pl-20 pl-xs-10">
                                                <h4
                                                    class="event-title media-heading font-raleway font-weight-700 mb-0 pt-5">
                                                    <a href="#">Gear up for giving</a></h4>
                                                <span class="mb-5 font-12 mr-10"><i
                                                        class="fa fa-clock-o mr-5 text-theme-colored"></i> at 5.00 pm -
                                                    7.30 pm</span>
                                                <span class="font-12"><i
                                                        class="fa fa-map-marker mr-5 text-theme-colored"></i> 25
                                                    Newyork City</span>
                                                <p class="mb-5">Lorem ipsum dolor sit amet</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="event media mt-0 no-bg no-border">
                                        <div class="event-date media-left text-center flip bg-theme-colored2 p-10">
                                            <ul class="mt-5 mt-sm-20">
                                                <li class="font-20 text-white font-weight-600">28</li>
                                                <li class="font-14 text-uppercase text-white">Feb</li>
                                            </ul>
                                        </div>
                                        <div class="media-body">
                                            <div class="event-content pull-left flip pl-20 pl-xs-10">
                                                <h4
                                                    class="event-title media-heading font-raleway font-weight-700 mb-0 pt-5">
                                                    <a href="#">Gear up for giving</a></h4>
                                                <span class="mb-5 font-12 mr-10"><i
                                                        class="fa fa-clock-o mr-5 text-theme-colored"></i> at 5.00 pm -
                                                    7.30 pm</span>
                                                <span class="font-12"><i
                                                        class="fa fa-map-marker mr-5 text-theme-colored"></i> 25
                                                    Newyork City</span>
                                                <p class="mb-5">Lorem ipsum dolor sit amet</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="event media mt-0 no-bg no-border">
                                        <div class="event-date media-left text-center flip bg-theme-colored3 p-10">
                                            <ul class="mt-5 mt-sm-20">
                                                <li class="font-20 text-white font-weight-600">28</li>
                                                <li class="font-14 text-uppercase text-white">Feb</li>
                                            </ul>
                                        </div>
                                        <div class="media-body">
                                            <div class="event-content pull-left flip pl-20 pl-xs-10">
                                                <h4
                                                    class="event-title media-heading font-raleway font-weight-700 mb-0 pt-5">
                                                    <a href="#">Gear up for giving</a></h4>
                                                <span class="mb-5 font-12 mr-10"><i
                                                        class="fa fa-clock-o mr-5 text-theme-colored"></i> at 5.00 pm -
                                                    7.30 pm</span>
                                                <span class="font-12"><i
                                                        class="fa fa-map-marker mr-5 text-theme-colored"></i> 25
                                                    Newyork City</span>
                                                <p class="mb-5">Lorem ipsum dolor sit amet</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="event media mt-0 no-bg no-border">
                                        <div class="event-date media-left text-center flip bg-theme-colored p-10">
                                            <ul class="mt-5 mt-sm-20">
                                                <li class="font-20 text-white font-weight-600">28</li>
                                                <li class="font-14 text-uppercase text-white">Feb</li>
                                            </ul>
                                        </div>
                                        <div class="media-body">
                                            <div class="event-content pull-left flip pl-20 pl-xs-10">
                                                <h4
                                                    class="event-title media-heading font-raleway font-weight-700 mb-0 pt-5">
                                                    <a href="#">Gear up for giving</a></h4>
                                                <span class="mb-5 font-12 mr-10"><i
                                                        class="fa fa-clock-o mr-5 text-theme-colored"></i> at 5.00 pm -
                                                    7.30 pm</span>
                                                <span class="font-12"><i
                                                        class="fa fa-map-marker mr-5 text-theme-colored"></i> 25
                                                    Newyork City</span>
                                                <p class="mb-5">Lorem ipsum dolor sit amet</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Section: Mission -->
            <section class="text-center bg-silver-light">
                <div class="container pb-70 pb-sm-60">
                    <div class="section-title">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <h2 class="text-center line-height-1 mt-0">Why<span class="text-theme-colored3">
                                        Choose</span> Us</h2>
                                <p class="text-center">Lorem ipsum dolor simply dummy text of the printing and
                                    typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever
                                    since the 1500s</p>
                            </div>
                        </div>
                    </div>
                    <div class="section-content">
                        <div class="row equal-height">
                            <div class="col-sm-4">
                                <div class="icon-box iconbox-theme-colored">
                                    <a class="icon icon-dark icon-bordered icon-rounded icon-border-effect effect-rounded mb-10"
                                        href="#">
                                        <i class="fa fa-building-o"></i>
                                    </a>
                                    <h4 class="icon-box-title">Cafeteria</h4>
                                    <p class="text-gray">Lorem ipsum dolor sit amet, consectetur elit. Etiam metus sed
                                        arcu pulvinar scelerisque sed tellus. Vestibulum ante ipsum primis</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="icon-box iconbox-theme-colored">
                                    <a class="icon icon-dark icon-bordered icon-rounded icon-border-effect effect-rounded mb-10"
                                        href="#">
                                        <i class="fa fa-male"></i>
                                    </a>
                                    <h4 class="icon-box-title">Best Teachers</h4>
                                    <p class="text-gray">Lorem ipsum dolor sit amet, consectetur elit. Etiam metus sed
                                        arcu pulvinar scelerisque sed tellus. Vestibulum ante ipsum primis</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="icon-box iconbox-theme-colored">
                                    <a class="icon icon-dark icon-bordered icon-rounded icon-border-effect effect-rounded mb-10"
                                        href="#">
                                        <i class="fa fa-laptop"></i>
                                    </a>
                                    <h4 class="icon-box-title">Excellent Lab</h4>
                                    <p class="text-gray">Lorem ipsum dolor sit amet, consectetur elit. Etiam metus sed
                                        arcu pulvinar scelerisque sed tellus. Vestibulum ante ipsum primis</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="icon-box iconbox-theme-colored">
                                    <a class="icon icon-dark icon-bordered icon-rounded icon-border-effect effect-rounded mb-10"
                                        href="#">
                                        <i class="fa fa-book"></i>
                                    </a>
                                    <h4 class="icon-box-title">Large Library</h4>
                                    <p class="text-gray">Lorem ipsum dolor sit amet, consectetur elit. Etiam metus sed
                                        arcu pulvinar scelerisque sed tellus. Vestibulum ante ipsum primis</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="icon-box iconbox-theme-colored">
                                    <a class="icon icon-dark icon-bordered icon-rounded icon-border-effect effect-rounded mb-10"
                                        href="#">
                                        <i class="fa fa-bus"></i>
                                    </a>
                                    <h4 class="icon-box-title">Transport Facility</h4>
                                    <p class="text-gray">Lorem ipsum dolor sit amet, consectetur elit. Etiam metus sed
                                        arcu pulvinar scelerisque sed tellus. Vestibulum ante ipsum primis</p>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="icon-box iconbox-theme-colored">
                                    <a class="icon icon-dark icon-bordered icon-rounded icon-border-effect effect-rounded mb-10"
                                        href="#">
                                        <i class="fa fa-wifi"></i>
                                    </a>
                                    <h4 class="icon-box-title">Internet Centre</h4>
                                    <p class="text-gray">Lorem ipsum dolor sit amet, consectetur elit. Etiam metus sed
                                        arcu pulvinar scelerisque sed tellus. Vestibulum ante ipsum primis</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Section: free-registration  -->
            <section>
                <div class="container pt-sm-70">
                    <div class="section-content">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-8">
                                <h2 class="line-bottom-edu">Our Admission <span
                                        class="text-theme-colored3">Quary</span></h2>
                                <p class="mb-20">We care for children, protect their welfare, and prepare them for the
                                    future are the most important issues we face during our lifetime.</p>
                                <div class="row mb-30">
                                    <div class="col-sm-6 col-md-6">
                                        <div class="info border-1px">
                                            <h4 class="mt-0 bg-theme-colored3 text-white pt-10 pb-10 pl-10">
                                                Undergraduate Admission</h4>
                                            <div class="timetable pb-10">
                                                <ul class="pr-10 pl-15">
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Spring 2019 Deadline <span
                                                            class="">October 1, 2017</span></li>
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Fall 2019 Deadline <span
                                                            class="">February 1, 2017</span></li>
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Summer 2019 Deadline <span
                                                            class="">May 1, 2017</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-6">
                                        <div class="info border-1px">
                                            <h4 class="mt-0 bg-theme-colored3 text-white pt-10 pb-10 pl-10">Graduate
                                                Admission</h4>
                                            <div class="timetable pb-10">
                                                <ul class="pr-10 pl-15">
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Spring 2019 Deadline <span
                                                            class="">October 1, 2017</span></li>
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Fall 2019 Deadline <span
                                                            class="">February 1, 2017</span></li>
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Summer 2019 Deadline <span
                                                            class="">May 1, 2017</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6 col-md-6">
                                        <div class="info border-1px">
                                            <h4 class="mt-0 bg-theme-colored3 text-white pt-10 pb-10 pl-10">Masters's
                                                Degree</h4>
                                            <div class="timetable pb-10">
                                                <ul class="pr-10 pl-15">
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Spring 2019 Deadline <span
                                                            class="">October 1, 2017</span></li>
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Fall 2019 Deadline <span
                                                            class="">February 1, 2017</span></li>
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Summer 2019 Deadline <span
                                                            class="">May 1, 2017</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-6">
                                        <div class="info border-1px">
                                            <h4 class="mt-0 bg-theme-colored3 text-white pt-10 pb-10 pl-10">Doctoral
                                                Degrees</h4>
                                            <div class="timetable pb-10">
                                                <ul class="pr-10 pl-15">
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Spring 2019 Deadline <span
                                                            class="">October 1, 2017</span></li>
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Fall 2019 Deadline <span
                                                            class="">February 1, 2017</span></li>
                                                    <li><i class="fa fa-check-square-o pr-10"
                                                            aria-hidden="true"></i>Summer 2019 Deadline <span
                                                            class="">May 1, 2017</span></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-6 col-md-4 wow fadeInLeft" data-wow-duration="1s"
                                data-wow-delay="0.3s">
                                <div class="p-30 bg-theme-colored mt-xs-30 mt-sm-30">
                                    <h3 class="text-white mt-0 mb-10">Get A Free Registration!</h3>
                                    <!-- Appilication Form Start-->
                                    <form id="reservation_form" name="reservation_form"
                                        class="reservation-form mt-20" method="post"
                                        action="https://kodesolution.com/html/2017/edupoints-html/demo/includes/reservation.php">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="form-group mb-20">
                                                    <input placeholder="Name" type="text" id="reservation_name"
                                                        name="reservation_name" required="" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group mb-20">
                                                    <input placeholder="Email" type="text" id="reservation_email"
                                                        name="reservation_email" class="form-control" required="">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group mb-20">
                                                    <input placeholder="Phone" type="text" id="reservation_phone"
                                                        name="reservation_phone" class="form-control" required="">
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group mb-20">
                                                    <div class="styled-select mt-0">
                                                        <select id="person_select" name="person_select"
                                                            class="form-control" required>
                                                            <option value="">Courses</option>
                                                            <option value="1 Person">Software Engineering</option>
                                                            <option value="2 Person">Computer Traning</option>
                                                            <option value="3 Person">Development Studies</option>
                                                            <option value="Family Pack">Chemical Engineering</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group mb-20">
                                                    <input name="Date" class="form-control required date-picker"
                                                        type="text" placeholder="Date" aria-required="true">
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <textarea placeholder="Enter Message" rows="3" class="form-control required" name="form_message"
                                                        id="form_message" aria-required="true"></textarea>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="form-group mb-0 mt-10">
                                                    <input name="form_botcheck" class="form-control" type="hidden"
                                                        value="">
                                                    <button type="submit"
                                                        class="btn btn-colored btn-default text-black btn-lg btn-block"
                                                        data-loading-text="Please wait...">Submit Request</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                    <!-- Application Form End-->

                                    <!-- Application Form Validation Start-->
                                    <script>
                                        $("#reservation_form").validate({
                                            submitHandler: function(form) {
                                                var form_btn = $(form).find('button[type="submit"]');
                                                var form_result_div = '#form-result';
                                                $(form_result_div).remove();
                                                form_btn.before(
                                                    '<div id="form-result" class="alert alert-success" role="alert" style="display: none;"></div>'
                                                    );
                                                var form_btn_old_msg = form_btn.html();
                                                form_btn.html(form_btn.prop('disabled', true).data("loading-text"));
                                                $(form).ajaxSubmit({
                                                    dataType: 'json',
                                                    success: function(data) {
                                                        if (data.status == 'true') {
                                                            $(form).find('.form-control').val('');
                                                        }
                                                        form_btn.prop('disabled', false).html(form_btn_old_msg);
                                                        $(form_result_div).html(data.message).fadeIn('slow');
                                                        setTimeout(function() {
                                                            $(form_result_div).fadeOut('slow')
                                                        }, 6000);
                                                    }
                                                });
                                            }
                                        });
                                    </script>
                                    <!-- Application Form Validation Start -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Section: -->
            <section class="layer-overlay overlay-theme-colored-9" data-bg-img="images/bg/bg3.jpg"
                data-parallax-ratio="0.7">
                <div class="container">
                    <div class="section-title">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <h2 class="text-white text-center line-height-1 mt-0">Our Success</h2>
                                <p class="text-white-f2 text-center">Lorem ipsum dolor simply dummy text of the
                                    printing and typesetting industry. Lorem Ipsum has been the industry's standard
                                    dummy text ever since the 1500s</p>
                            </div>
                        </div>
                    </div>
                    <div class="section-content">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-6 col-md-3 wow fadeInLeft" data-wow-duration="1s"
                                        data-wow-delay="0.3s">
                                        <div class="funfact">
                                            <i class="pe-7s-notebook text-white mt-20 font-48 pull-left flip"></i>
                                            <div class="ml-60">
                                                <h2 class="animate-number text-white-f1 mt-0 mb-0 font-48 line-bottom-white"
                                                    data-value="280" data-animation-duration="2000">0</h2>
                                                <div class="clearfix"></div>
                                                <h5 class="text-white-f2">Courses</h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-6 col-md-3 wow fadeInLeft" data-wow-duration="1s"
                                        data-wow-delay="0.4s">
                                        <div class="funfact">
                                            <i class="pe-7s-users text-white mt-20 font-48 pull-left flip"></i>
                                            <div class="ml-60">
                                                <h2 class="animate-number text-white-f1 mt-0 mb-0 font-48 line-bottom-white"
                                                    data-value="15K" data-animation-duration="2500">0</h2>
                                                <div class="clearfix"></div>
                                                <h5 class="text-white-f2">Students</h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-6 col-md-3 wow fadeInLeft" data-wow-duration="1s"
                                        data-wow-delay="0.5s">
                                        <div class="funfact">
                                            <i class="pe-7s-study text-white mt-20 font-48 pull-left flip"></i>
                                            <div class="ml-60">
                                                <h2 class="animate-number text-white-f1 mt-0 mb-0 font-48 line-bottom-white"
                                                    data-value="10K" data-animation-duration="3000">0</h2>
                                                <div class="clearfix"></div>
                                                <h5 class="text-white-f2">Graduate Students</h5>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xs-12 col-sm-6 col-md-3 wow fadeInLeft" data-wow-duration="1s"
                                        data-wow-delay="0.5s">
                                        <div class="funfact">
                                            <i class="pe-7s-cup text-white mt-20 font-48 pull-left flip"></i>
                                            <div class="ml-60">
                                                <h2 class="animate-number text-white-f1 mt-0 mb-0 font-48 line-bottom-white"
                                                    data-value="189" data-animation-duration="3000">0</h2>
                                                <div class="clearfix"></div>
                                                <h5 class="text-white-f2">Awards</h5>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Section: -->
            <section id="courses">
                <div class="container">
                    <div class="section-title text-center">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2">
                                <h2 class="text-center line-height-1 mt-0">Popular <span
                                        class="text-theme-colored3">Courses</span> </h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus hic suscipit
                                    doloremque deleniti ipsa quia dolor laborum natus tenetur, excepturi?</p>
                            </div>
                        </div>
                    </div>
                    <div class="section-content">
                        <div class="row mtli-row-clearfix">
                            <div class="col-md-12">
                                <div class="horizontal-tab-centered">
                                    <div class="text-center">
                                        <ul class="nav nav-pills mb-10">
                                            <li class="active"> <a href="#tab-20" class="" data-toggle="tab"
                                                    aria-expanded="false"> <i class="fa fa-graduation-cap"
                                                        aria-hidden="true"></i>Faculty of Arts</a> </li>
                                            <li class=""> <a href="#tab-21" data-toggle="tab"
                                                    aria-expanded="false"> <i class="fa fa-leanpub"></i>Faculty of
                                                    Commerce</a> </li>
                                            <li class=""> <a href="#tab-22" data-toggle="tab"
                                                    aria-expanded="true"> <i class="fa fa-book"></i>Faculty of
                                                    Science</a> </li>
                                            <li class=""> <a href="#tab-23" data-toggle="tab"
                                                    aria-expanded="false"> <i class="fa fa-certificate">
                                                    </i>Postgraduate</a> </li>
                                            <li class=""> <a href="#tab-24" data-toggle="tab"
                                                    aria-expanded="false"> <i class="fa fa-university"
                                                        aria-hidden="true"></i>Research Higher Degree</a> </li>
                                        </ul>
                                    </div>
                                    <div class="panel-body p-0">
                                        <div class="tab-content p-0">
                                            <div class="tab-pane fade active in" id="tab-20">
                                                <div class="row">
                                                    <div class="col-sm-3 col-md-3 col-lg-3 wow fadeInUp"
                                                        data-wow-duration="1s" data-wow-delay="0.3s">
                                                        <div class="services mb-xs-30">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/1.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1 sm-text-center"><a
                                                                            href="#">Anthropology</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left xs-pull-left  sm-pull-none sm-text-center">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right sm-pull-none xs-pull-right sm-text-center mt-sm-10 mt-xs-0">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li
                                                                            class="pull-left sm-pull-none xs-pull-left sm-text-center flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">4
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right sm-pull-none xs-pull-right sm-text-center flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3 col-md-3 col-lg-3 wow fadeInUp"
                                                        data-wow-duration="1s" data-wow-delay="0.5s">
                                                        <div class="services mb-xs-30">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/2.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1 sm-text-center"><a
                                                                            href="#">Philosophy</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left xs-pull-left sm-pull-none sm-text-center">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right xs-pull-right sm-pull-none sm-text-center mt-sm-10 mt-xs-0">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li
                                                                            class="pull-left sm-pull-none sm-text-center flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">4
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right sm-pull-none sm-text-center flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3 col-md-3 col-lg-3 wow fadeInUp"
                                                        data-wow-duration="1s" data-wow-delay="0.7s">
                                                        <div class="services mb-xs-30">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/3.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1 sm-text-center"><a
                                                                            href="#">Public Policy</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left xs-pull-left sm-pull-none sm-text-center">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right xs-pull-right sm-pull-none sm-text-center mt-sm-10 mt-xs-0">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li
                                                                            class="pull-left xs-pull-left sm-pull-none sm-text-center flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">4
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right xs-pull-right sm-pull-none sm-text-center flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3 col-md-3 col-lg-3 wow fadeInUp"
                                                        data-wow-duration="1s" data-wow-delay="0.9s">
                                                        <div class="services">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/4.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1 sm-text-center"><a
                                                                            href="#">Sociology</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left xs-pull-left sm-pull-none sm-text-center">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right xs-pull-right sm-pull-none sm-text-center mt-sm-10 mt-xs-0">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li
                                                                            class="pull-left xs-pull-left sm-pull-none sm-text-center flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">4
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right xs-pull-right sm-pull-none sm-text-center flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane fade" id="tab-21">
                                                <div class="row">
                                                    <div class="col-sm-4 col-md-4 col-lg-4">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/5.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Accounting</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span
                                                                                class="font-weight-700">$189</span>
                                                                        </li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4 col-md-4 col-lg-4">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/6.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Finance and Tax</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span
                                                                                class="font-weight-700">$189</span>
                                                                        </li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4 col-md-4 col-lg-4">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/7.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">School of Management</a>
                                                                    </h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span
                                                                                class="font-weight-700">$189</span>
                                                                        </li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane fade" id="tab-22">
                                                <div class="row">
                                                    <div class="col-sm-3 col-md-3 col-lg-3">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/10.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Biochemistry</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">4
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3 col-md-3 col-lg-3">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/7.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Physics</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">4
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3 col-md-3 col-lg-3">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/8.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Chemistry</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">4
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3 col-md-3 col-lg-3">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/9.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Mathematics</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">4
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane fade" id="tab-23">
                                                <div class="row">
                                                    <div class="col-sm-3 col-md-3 col-lg-3">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/1.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Molecular Imaging</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">1.5
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">40</span></li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3 col-md-3 col-lg-3">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/2.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Bioinformatics</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">1.5
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">40</span></li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3 col-md-3 col-lg-3">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/3.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Data Science</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">2
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">50</span></li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-3 col-md-3 col-lg-3">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/4.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Mineral Resources</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span class="font-weight-700">2
                                                                                Years</span></li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">50</span></li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tab-pane fade" id="tab-24">
                                                <div class="row">
                                                    <div class="col-sm-4 col-md-4 col-lg-4">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/5.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Plant Biology</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span
                                                                                class="font-weight-700">$189</span>
                                                                        </li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">48
                                                                                weeks</span></li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4 col-md-4 col-lg-4">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/6.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">Geology</a></h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span
                                                                                class="font-weight-700">$189</span>
                                                                        </li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">40
                                                                                weeks</span></li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4 col-md-4 col-lg-4">
                                                        <div class="services mb-sm-50">
                                                            <div class="thumb">
                                                                <img class="img-fullwidth" alt=""
                                                                    src="<?php echo e(asset('/')); ?>/assets/web/images/project/7.jpg">
                                                            </div>
                                                            <div class="services-details clearfix">
                                                                <div class="p-20 p-sm-15 bg-lighter">
                                                                    <h4 class="mt-0 line-height-1"><a
                                                                            href="#">School of Management</a>
                                                                    </h4>
                                                                    <ul
                                                                        class="list-inline text-theme-colored2 pull-left">
                                                                        <li>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                            <i class="fa fa-star"
                                                                                aria-hidden="true"></i>
                                                                        </li>
                                                                    </ul>
                                                                    <div
                                                                        class="course-price bg-theme-colored3 pull-right">
                                                                        <span class="text-white">$200</span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                    <ul class="list-inline mt-15 mb-10 clearfix">
                                                                        <li class="pull-left flip pr-0 clearfix">
                                                                            Course: <span
                                                                                class="font-weight-700">$189</span>
                                                                        </li>
                                                                        <li
                                                                            class="text-theme-colored pull-right flip pr-0">
                                                                            Class Size: <span
                                                                                class="font-weight-700">110</span>
                                                                        </li>
                                                                    </ul>
                                                                    <a class="btn btn-dark btn-theme-colored btn-sm text-uppercase mt-10"
                                                                        href="#">Learn Now</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Section: -->
            <section data-bg-img="images/bg/bg6.jpg">
                <div class="container-fluid p-0">
                    <div class="section-content">
                        <div class="row">
                            <div class="col-md-6"></div>
                            <div class="col-md-6 bg-theme-colored">
                                <h3 class="text-center line-height-1 text-white mt-100 mb-15 mt-sm-0 pt-sm-100">Our
                                    Client's Say</h3>
                                <div class="owl-carousel-1col pr-150 pl-150 pr-sm-50 pl-sm-50 pb-90"
                                    data-dots="true">
                                    <div class="item">
                                        <div class="testimonial-wrapper text-center">
                                            <div class="content">
                                                <i
                                                    class="fa fa-quote-left text-theme-colored2 font-42 mt-15 mb-10 mb-sm-0"></i>
                                                <a class="mt-20 mb-15 display-block" href="#">
                                                    <img alt=""
                                                        src="<?php echo e(asset('/')); ?>/assets/web/images/testimonials/2.jpg"
                                                        class="img-circle">
                                                </a>
                                                <p class="mb-sm-10 text-white-f3">Lorem Ipsum has been the industry's
                                                    standard dummy text ever, when an took a galley of type and it to
                                                    make a type book.It has survived the leap into</p>
                                                <h4 class="service-box-title font-weight-800 text-white-f3">Corvin
                                                    Adams</h4>
                                                <span
                                                    class="text-theme-colored2 font-14 font-weight-600 mt-5 mt-sm-0">web
                                                    Desinger (ceo)</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="testimonial-wrapper text-center">
                                            <div class="content">
                                                <i
                                                    class="fa fa-quote-left text-theme-colored2 font-42 mt-15 mb-10 mb-sm-0"></i>
                                                <a class="mt-20 mb-15 display-block" href="#">
                                                    <img alt=""
                                                        src="<?php echo e(asset('/')); ?>/assets/web/images/testimonials/1.jpg"
                                                        class="img-circle">
                                                </a>
                                                <p class="mb-sm-10 text-white-f3">Lorem Ipsum has been the industry's
                                                    standard dummy text ever, when an took a galley of type and it to
                                                    make a type book.It has survived the leap into</p>
                                                <h4 class="service-box-title font-weight-800 text-white-f3">Jhon Doe
                                                </h4>
                                                <span
                                                    class="text-theme-colored2 font-14 font-weight-600 mt-5 mt-sm-0">Web
                                                    Developer (Maneger)</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <div class="testimonial-wrapper text-center">
                                            <div class="content">
                                                <i
                                                    class="fa fa-quote-left text-theme-colored2 font-42 mt-15 mb-10 mb-sm-0"></i>
                                                <a class="mt-20 mb-15 display-block" href="#">
                                                    <img alt=""
                                                        src="<?php echo e(asset('/')); ?>/assets/web/images/testimonials/2.jpg"
                                                        class="img-circle">
                                                </a>
                                                <p class="mb-sm-10 text-white-f3">Lorem Ipsum has been the industry's
                                                    standard dummy text ever, when an took a galley of type and it to
                                                    make a type book.It has survived the leap into</p>
                                                <h4 class="service-box-title font-weight-800 text-white-f3">Corvin
                                                    Adams</h4>
                                                <span
                                                    class="text-theme-colored2 font-14 font-weight-600 mt-5 mt-sm-0">Web
                                                    Desinger (QC)</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Section:  -->
            <section id="team">
                <div class="container pb-sm-70">
                    <div class="section-title text-center">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2">
                                <h2 class="mt-0 line-height-1">Faculty <span
                                        class="text-theme-colored3">Members</span></h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.Acque quidem eaque, amet
                                    doloribus, error inventore, quisquam totam magni cumque.</p>
                            </div>
                        </div>
                    </div>
                    <div class="section-content text-center">
                        <div class="row">
                            <div class="col-sm-6 col-md-3 mb-sm-30">
                                <div class="team-block bg-light pt-10 pb-15">
                                    <div class="team-thumb"><img class="img-fullwidth"
                                            src="<?php echo e(asset('/')); ?>/assets/web/images/team/1.png" alt="">
                                    </div>
                                    <div class="info">
                                        <div class="pt-10 pb-10 bg-theme-colored2">
                                            <h4 class="mt-0 mb-0 text-white">Jone doe</h4>
                                            <h6 class="mt-0 mb-0 text-white">Manager</h6>
                                        </div>
                                        <p class="p-15 pb-0">Lorem ipsum dolor sit amet cing, consectetur adipisi. Vel
                                            consectetur.</p>
                                        <ul
                                            class="styled-icons icon-theme-colored icon-circled icon-dark icon-sm mt-15 mb-0">
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3 mb-sm-30">
                                <div class="team-block bg-light pt-10 pb-15">
                                    <div class="team-thumb"><img class="img-fullwidth"
                                            src="<?php echo e(asset('/')); ?>/assets/web/images/team/2.png" alt="">
                                    </div>
                                    <div class="info">
                                        <div class="pt-10 pb-10 bg-theme-colored">
                                            <h4 class="mt-0 mb-0 text-white">Jone doe</h4>
                                            <h6 class="mt-0 mb-0 text-white">Manager</h6>
                                        </div>
                                        <p class="p-15 pb-0">Lorem ipsum dolor sit amet cing, consectetur adipisi. Vel
                                            consectetur.</p>
                                        <ul
                                            class="styled-icons icon-theme-colored3 icon-circled icon-dark icon-sm mt-15 mb-0">
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3 mb-sm-30">
                                <div class="team-block bg-light pt-10 pb-15">
                                    <div class="team-thumb"><img class="img-fullwidth"
                                            src="<?php echo e(asset('/')); ?>/assets/web/images/team/3.png" alt="">
                                    </div>
                                    <div class="info">
                                        <div class="pt-10 pb-10 bg-theme-colored3">
                                            <h4 class="mt-0 mb-0 text-white">Jone doe</h4>
                                            <h6 class="mt-0 mb-0 text-white">Manager</h6>
                                        </div>
                                        <p class="p-15 pb-0">Lorem ipsum dolor sit amet cing, consectetur adipisi. Vel
                                            consectetur.</p>
                                        <ul
                                            class="styled-icons icon-theme-colored icon-circled icon-dark icon-sm mt-15 mb-0">
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 col-md-3 mb-sm-30">
                                <div class="team-block bg-light pt-10 pb-15">
                                    <div class="team-thumb"><img class="img-fullwidth"
                                            src="<?php echo e(asset('/')); ?>/assets/web/images/team/4.png" alt="">
                                    </div>
                                    <div class="info">
                                        <div class="pt-10 pb-10 bg-theme-colored">
                                            <h4 class="mt-0 mb-0 text-white">Jone doe</h4>
                                            <h6 class="mt-0 mb-0 text-white">Manager</h6>
                                        </div>
                                        <p class="p-15 pb-0">Lorem ipsum dolor sit amet cing, consectetur adipisi. Vel
                                            consectetur.</p>
                                        <ul
                                            class="styled-icons icon-theme-colored2 icon-circled icon-dark icon-sm mt-15 mb-0">
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Divider: -->
            <section class="divider parallax layer-overlay overlay-dark-8 text-center"
                data-bg-img="images/bg/bg5.jpg" data-parallax-ratio="0.7">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <h2 class="mt-0 text-white">Unlimited Support &amp; Easily Customizable</h2>
                            <h4 class="text-white">Subscribe to Connect with us</h4>

                            <!-- Mailchimp Subscription Form-->
                            <form id="mailchimp-subscription-form3" class="newsletter-form mt-30">
                                <label for="mce-EMAIL"></label>
                                <div class="input-group">
                                    <input type="email" id="mce-EMAIL" data-height="50px"
                                        class="form-control input-lg" placeholder="Your Email" name="EMAIL"
                                        value="">
                                    <span class="input-group-btn">
                                        <button type="submit" class="btn btn-colored btn-theme-colored btn-lg m-0"
                                            data-height="50px"><i class="fa fa-paper-plane-o font-20"
                                                aria-hidden="true"></i>
                                        </button>
                                    </span>
                                </div>
                            </form>

                            <!-- Mailchimp Subscription Form Validation-->
                            <script>
                                $('#mailchimp-subscription-form3').ajaxChimp({
                                    callback: mailChimpCallBack,
                                    url: '//thememascot.us9.list-manage.com/subscribe/post?u=a01f440178e35febc8cf4e51f&amp;id=49d6d30e1e'
                                });

                                function mailChimpCallBack(resp) {
                                    // Hide any previous response text
                                    var $mailchimpform = $('#mailchimp-subscription-form3'),
                                        $response = '';
                                    $mailchimpform.children(".alert").remove();
                                    if (resp.result === 'success') {
                                        $response =
                                            '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                                            resp.msg + '</div>';
                                    } else if (resp.result === 'error') {
                                        $response =
                                            '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                                            resp.msg + '</div>';
                                    }
                                    $mailchimpform.prepend($response);
                                }
                            </script>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Section: blog -->
            <section id="blog">
                <div class="container pb-70">
                    <div class="section-title text-center">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12">
                                <h2 class="mt-0 line-height-1 text-center">Latest <span
                                        class="text-theme-colored3">News</span></h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem temporibus
                                    quisquam voluptas natus, provident porro et odio perferendis ipsam, amet sint</p>
                            </div>
                        </div>
                    </div>
                    <div class="section-content">
                        <div class="row">
                            <div class="col-sm-6 col-md-4 col-lg-4">
                                <article class="post clearfix maxwidth600 mb-30 border-1px">
                                    <div class="entry-header-new">
                                        <div class="post-thumb thumb"><img
                                                src="<?php echo e(asset('/')); ?>/assets/web/images/blog/1.jpg"
                                                alt="" class="img-responsive img-fullwidth">
                                        </div>
                                        <div class="blog-overlay"></div>
                                    </div>
                                    <div class="pr-20 pl-20 pb-30 text-center">
                                        <h3 class="entry-title mt-20 pt-0"><a class="text-theme-colored"
                                                href="#">The Celebration</a></h3>
                                        <ul class="list-inline entry-date font-13 mt-5">
                                            <li><i class="fa fa-clock-o mr-5 text-theme-colored"></i> Dec - 21 </li>
                                            <li><i class="fa fa-map-marker mr-5 text-theme-colored"></i> 121 King
                                                Street, Melbourne </li>
                                        </ul>
                                        <p class="mt-10">Lorem ipsum dolor sit amet. Reiciendis impedit expedita sit
                                            deleniti culpa nam fuga neque similique corporis.</p>
                                        <a class="btn btn-theme-colored btn-lg btn-flat mt-0 text-white mt-10"
                                            href="#">Read more <i
                                                class="fa fa-angle-double-right text-theme-colored2"></i></a>
                                    </div>
                                </article>
                            </div>
                            <div class="col-sm-6 col-md-4 col-lg-4">
                                <article class="post clearfix maxwidth600 mb-30 border-1px">
                                    <div class="entry-header-new">
                                        <div class="post-thumb thumb"><img
                                                src="<?php echo e(asset('/')); ?>/assets/web/images/blog/2.jpg"
                                                alt="" class="img-responsive img-fullwidth">
                                        </div>
                                        <div class="blog-overlay"></div>
                                    </div>
                                    <div class="pr-20 pl-20 pb-30 text-center">
                                        <h3 class="entry-title mt-20 pt-0"><a class="text-theme-colored"
                                                href="#">The Celebration</a></h3>
                                        <ul class="list-inline entry-date font-13 mt-5">
                                            <li><i class="fa fa-clock-o mr-5 text-theme-colored"></i> Dec - 21 </li>
                                            <li><i class="fa fa-map-marker mr-5 text-theme-colored"></i> 121 King
                                                Street, Melbourne </li>
                                        </ul>
                                        <p class="mt-10">Lorem ipsum dolor sit amet. Reiciendis impedit expedita sit
                                            deleniti culpa nam fuga neque similique corporis.</p>
                                        <a class="btn btn-theme-colored btn-lg btn-flat mt-0 text-white mt-10"
                                            href="#">Read more <i
                                                class="fa fa-angle-double-right text-theme-colored2"></i></a>
                                    </div>
                                </article>
                            </div>
                            <div class="col-sm-6 col-md-4 col-lg-4">
                                <article class="post clearfix maxwidth600 mb-30 border-1px">
                                    <div class="entry-header-new">
                                        <div class="post-thumb thumb"><img
                                                src="<?php echo e(asset('/')); ?>/assets/web/images/blog/3.jpg"
                                                alt="" class="img-responsive img-fullwidth">
                                        </div>
                                        <div class="blog-overlay"></div>
                                    </div>
                                    <div class="pr-20 pl-20 pb-30 text-center">
                                        <h3 class="entry-title mt-20 pt-0"><a class="text-theme-colored"
                                                href="#">The Celebration</a></h3>
                                        <ul class="list-inline entry-date font-13 mt-5">
                                            <li><i class="fa fa-clock-o mr-5 text-theme-colored"></i> Dec - 21 </li>
                                            <li><i class="fa fa-map-marker mr-5 text-theme-colored"></i> 121 King
                                                Street, Melbourne </li>
                                        </ul>
                                        <p class="mt-10">Lorem ipsum dolor sit amet. Reiciendis impedit expedita sit
                                            deleniti culpa nam fuga neque similique corporis.</p>
                                        <a class="btn btn-theme-colored btn-lg btn-flat mt-0 text-white mt-10"
                                            href="#">Read more <i
                                                class="fa fa-angle-double-right text-theme-colored2"></i></a>
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Divider: Reservation Form -->
            <section id="reservation" class="bg-silver-light">
                <div class="container pt-sm-30 pb-sm-50">
                    <div class="section-title text-center">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2 col-sm-12 col-xs-12">
                                <h2 class="mt-0 line-height-1 text-center">Contact <span
                                        class="text-theme-colored3">Us</span></h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur quidem temporibus
                                    quisquam voluptas natus, provident porro et odio perferendis ipsam, amet sint</p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="mt-10 mt-sm-40">
                                <!-- Reservation Form Start-->
                                <form id="reservation_form_new" name="reservation_form" class="reservation-form"
                                    method="post"
                                    action="https://kodesolution.com/html/2017/edupoints-html/demo/includes/reservation.php"
                                    novalidate>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group mb-20">
                                                <input placeholder="Enter Name" name="reservation_name"
                                                    required="" class="form-control" aria-required="true"
                                                    type="text">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group mb-20">
                                                <input placeholder="Your Email" name="reservation_email"
                                                    class="form-control" required="" aria-required="true"
                                                    type="text">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group mb-20">
                                                <input placeholder="Phone" name="reservation_phone"
                                                    class="form-control" required="" aria-required="true"
                                                    type="text">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group mb-20">
                                                <div class="styled-select">
                                                    <select id="car_select" name="car_select" class="form-control"
                                                        required aria-required="true">
                                                        <option value="">- Select Your Categories -</option>
                                                        <option value="Toyota">Business</option>
                                                        <option value="Jeep">Consulting</option>
                                                        <option value="Audi">Finance</option>
                                                        <option value="Truck">Professional</option>
                                                        <option value="Land Rover">Marketing</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-12">
                                            <div class="form-group mb-20">
                                                <textarea class="form-control" name="message" placeholder="Discuss with us about consulting" rows="3"
                                                    required></textarea>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group mb-0 mt-0">
                                                <input name="form_botcheck" class="form-control" value=""
                                                    type="hidden">
                                                <button type="submit" class="btn btn-default btn-block pt-10 pb-10"
                                                    data-loading-text="Please wait...">Submit Now</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <!-- Reservation Form End-->

                                <!-- Reservation Form Validation Start-->
                                <script>
                                    $("#reservation_form_new").validate({
                                        submitHandler: function(form) {
                                            var form_btn = $(form).find('button[type="submit"]');
                                            var form_result_div = '#form-result';
                                            $(form_result_div).remove();
                                            form_btn.before(
                                                '&amp;lt;div id="form-result" class="alert alert-success" role="alert" style="display: none;"&amp;gt;&amp;lt;/div&amp;gt;'
                                                );
                                            var form_btn_old_msg = form_btn.html();
                                            form_btn.html(form_btn.prop('disabled', true).data("loading-text"));
                                            $(form).ajaxSubmit({
                                                dataType: 'json',
                                                success: function(data) {
                                                    if (data.status == 'true') {
                                                        $(form).find('.form-control').val('');
                                                    }
                                                    form_btn.prop('disabled', false).html(form_btn_old_msg);
                                                    $(form_result_div).html(data.message).fadeIn('slow');
                                                    setTimeout(function() {
                                                        $(form_result_div).fadeOut('slow')
                                                    }, 6000);
                                                }
                                            });
                                        }
                                    });
                                </script>
                                <!-- Reservation Form Validation Start -->
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="row">
                                <div class="col-sm-6 col-md-12">
                                    <div class="icon-box icon-left iconbox-theme-colored">
                                        <a class="icon icon-gray icon-circled icon-border-effect effect-circled icon-sm pull-left flip"
                                            href="#">
                                            <i class="fa fa-phone-square"></i>
                                        </a>
                                        <h4 class="icon-box-title mb-5">Call us today!</h4>
                                        <p class="text-gray">+(012) 345 6789</p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-12">
                                    <div class="icon-box icon-left iconbox-theme-colored">
                                        <a class="icon icon-gray icon-circled icon-border-effect effect-circled icon-sm pull-left flip"
                                            href="#">
                                            <i class="fa fa-envelope"></i>
                                        </a>
                                        <h5 class="icon-box-title mb-5">Mail Us</h5>
                                        <p class="text-gray">info@yourdomain.com</p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-12">
                                    <div class="icon-box icon-left iconbox-theme-colored">
                                        <a class="icon icon-gray icon-circled icon-border-effect effect-circled icon-sm pull-left flip"
                                            href="#">
                                            <i class="fa fa-map-marker"></i>
                                        </a>
                                        <h4 class="icon-box-title mb-5">Location</h4>
                                        <p class="text-gray">Behind Alis Steet, Australia</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="bg-theme-colored">
                <div class="container pt-0 pb-0">
                    <div class="call-to-action pt-30 pb-20">
                        <div class="row">
                            <div class="col-md-9">
                                <h3 class="mt-0 text-white font-30">Become An Instructor</h3>
                                <p class="text-white">Lorem ipsum dolor sit , elit.Acque quidem eaque</p>
                            </div>
                            <div class="col-md-3">
                                <a href="#" class="btn btn-colored btn-gray btn-lg mt-20">Purchase Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- end main-content -->

        <!-- Footer -->
<?php echo $__env->make('web.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a class="scrollToTop" href="#"><i class="flaticon-seo-transport-3"></i></a>
    </div>
    <!-- end wrapper -->

    <!-- Footer Scripts -->
    <!-- JS | Custom script for all pages -->
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/custom.js"></script>

    <!-- SLIDER REVOLUTION 5.0 EXTENSIONS
      (Load Extensions only on Local File Systems !
       The following part can be removed on Server for On Demand Loading) -->
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/js/extensions/revolution.extension.actions.min.js">
    </script>
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/js/extensions/revolution.extension.carousel.min.js">
    </script>
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/js/extensions/revolution.extension.kenburn.min.js">
    </script>
    <script
        src="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/js/extensions/revolution.extension.layeranimation.min.js">
    </script>
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/js/extensions/revolution.extension.migration.min.js">
    </script>
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/js/extensions/revolution.extension.navigation.min.js">
    </script>
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/js/extensions/revolution.extension.parallax.min.js">
    </script>
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/js/extensions/revolution.extension.slideanims.min.js">
    </script>
    <script src="<?php echo e(asset('/')); ?>/assets/web/js/revolution-slider/js/extensions/revolution.extension.video.min.js">
    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\school\resources\views/web/app/app.blade.php ENDPATH**/ ?>