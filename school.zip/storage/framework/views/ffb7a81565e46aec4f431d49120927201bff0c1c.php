<section>
    <div class="container pt-sm-70">
        <div class="section-content">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-8">
                    <h2 class="line-bottom-edu">Our Admission <span class="text-theme-colored3">Quary</span>
                    </h2>
                    <p class="mb-20">We care for children, protect their welfare, and prepare them for the
                        future are the most important issues we face during our lifetime.</p>
                    <div class="row mb-30">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-6 col-md-6">
                            <div class="info border-1px">
                                <h4 class="mt-0 bg-theme-colored3 text-white pt-10 pb-10 pl-10">
                                    <?php echo e($course->name); ?></h4>
                                <div class="timetable pb-10">
                                    <p class="px-2"><?php echo e($course->description); ?></p>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 wow fadeInLeft" data-wow-duration="1s"
                    data-wow-delay="0.3s">
                    <div class="p-30 bg-theme-colored mt-xs-30 mt-sm-30">
                        <h3 class="text-white mt-0 mb-10">Get A Free Registration!</h3>
                        <!-- Appilication Form Start-->
                        <form id="reservation_form" name="reservation_form" class="reservation-form mt-20"
                            method="post"
                            action="<?php echo e(route('admissions.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group mb-20">
                                        <input placeholder="Name" type="text" id="reservation_name"
                                            name="reservation_name" required="" class="form-control">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group mb-20">
                                        <input placeholder="Email" type="text" id="reservation_email"
                                            name="reservation_email" class="form-control" required="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group mb-20">
                                        <input placeholder="Phone" type="text" id="reservation_phone"
                                            name="reservation_phone" class="form-control" required="">
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group mb-20">
                                        <div class="styled-select mt-0">
                                            <select id="reservation_course" name="reservation_course"
                                                class="form-control" required>

                                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <textarea placeholder="Enter Message" rows="3" class="form-control required" name="reservation_message"
                                            id="reservation_message" aria-required="true" ></textarea>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group mb-0 mt-10">

                                        <button type="submit"
                                            class="btn btn-colored btn-default text-black btn-lg btn-block"
                                            data-loading-text="Please wait...">Submit Request</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!-- Application Form End-->


                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\school-cms\resources\views/web/component/querry.blade.php ENDPATH**/ ?>